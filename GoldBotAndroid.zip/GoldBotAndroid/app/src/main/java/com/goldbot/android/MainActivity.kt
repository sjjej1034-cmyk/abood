package com.goldbot.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

private val Bg = Color(0xFF05070A)
private val Panel = Color(0xFF0D1117)
private val Grid = Color(0xFF252B33)
private val Green = Color(0xFF18C7A0)
private val Red = Color(0xFFFF5364)
private val Text = Color(0xFFE9EEF5)
private val Muted = Color(0xFF8C98A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldBotApp() }
    }
}

@Composable
fun GoldBotApp() {
    var tab by remember { mutableStateOf(0) }
    var symbol by remember { mutableStateOf("XAUUSD") }
    var timeframe by remember { mutableStateOf("M5") }
    var botRunning by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val items = listOf(
                        "الرسم" to Icons.Default.ShowChart,
                        "البوتات" to Icons.Default.Bolt,
                        "صفقات" to Icons.Default.List,
                        "تنبيهات" to Icons.Default.Notifications,
                        "إعدادات" to Icons.Default.Settings
                    )
                    items.forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(item.second, null) },
                            label = { Text(item.first, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> ChartScreen(Modifier.padding(pad), symbol, timeframe, { symbol = it }, { timeframe = it }, botRunning, { botRunning = it })
                1 -> BotsScreen(Modifier.padding(pad), botRunning) { botRunning = it }
                2 -> TradesScreen(Modifier.padding(pad))
                3 -> AlertsScreen(Modifier.padding(pad))
                else -> SettingsScreen(Modifier.padding(pad))
            }
        }
    }
}

@Composable
fun ChartScreen(
    modifier: Modifier,
    symbol: String,
    timeframe: String,
    onSymbol: (String) -> Unit,
    onTimeframe: (String) -> Unit,
    botRunning: Boolean,
    onBot: (Boolean) -> Unit
) {
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("$symbol  ·  $timeframe", color = Text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Gold vs US Dollar", color = Muted, fontSize = 12.sp)
            }
            Text(if (botRunning) "BOT ON" else "BOT OFF", color = if (botRunning) Green else Red, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("XAUUSD","EURUSD","GBPUSD","USDJPY").forEach {
                FilterChip(selected = symbol == it, onClick = { onSymbol(it) }, label = { Text(it) })
                Spacer(Modifier.width(6.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("M1","M5","M15","M30","H1","H4").forEach {
                FilterChip(selected = timeframe == it, onClick = { onTimeframe(it) }, label = { Text(it) })
                Spacer(Modifier.width(6.dp))
            }
        }
        Spacer(Modifier.height(10.dp))

        PriceChart(
            Modifier.fillMaxWidth().weight(1f),
            price = "4130.77",
            signal = if (botRunning) "BUY" else "WAIT"
        )

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            InfoCard("السعر", "4130.77", Modifier.weight(1f))
            InfoCard("الاتجاه", if (botRunning) "BUY" else "WAIT", Modifier.weight(1f))
            InfoCard("الفريم", timeframe, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { onBot(!botRunning) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = if (botRunning) Red else Green)
        ) {
            Icon(if (botRunning) Icons.Default.Stop else Icons.Default.PlayArrow, null)
            Spacer(Modifier.width(8.dp))
            Text(if (botRunning) "إيقاف البوت" else "تشغيل البوت", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun PriceChart(modifier: Modifier, price: String, signal: String) {
    Box(modifier.background(Color.Black, RoundedCornerShape(10.dp)).border(1.dp, Grid, RoundedCornerShape(10.dp))) {
        Canvas(Modifier.fillMaxSize().padding(10.dp)) {
            val w = size.width
            val h = size.height
            for (x in 0..10) {
                val xx = w * x / 10f
                drawLine(Grid, Offset(xx, 0f), Offset(xx, h), 1f)
            }
            for (y in 0..8) {
                val yy = h * y / 8f
                drawLine(Grid, Offset(0f, yy), Offset(w, yy), 1f)
            }

            val candles = 52
            val cw = w / candles * .55f
            for (i in 0 until candles) {
                val base = h * (0.48f - 0.18f * sin(i * .37f) - 0.08f * sin(i * .91f))
                val body = 12f + (i % 5) * 3
                val x = (i + .5f) * w / candles
                val up = i % 3 != 0
                val c = if (up) Green else Red
                drawLine(c, Offset(x, base - body - 12), Offset(x, base + body + 12), 2f)
                drawRect(c, androidx.compose.ui.geometry.Rect(x - cw/2, base - body, x + cw/2, base + body))
            }
            if (signal == "BUY") {
                val p = Path().apply {
                    moveTo(w * .78f, h * .25f)
                    lineTo(w * .78f, h * .12f)
                    lineTo(w * .75f, h * .17f)
                    moveTo(w * .78f, h * .12f)
                    lineTo(w * .81f, h * .17f)
                }
                drawPath(p, Green, style = Stroke(width = 6f, cap = StrokeCap.Round))
            }
        }
        Text("4130.77", color = Text, modifier = Modifier.align(Alignment.CenterEnd).padding(8.dp), fontSize = 12.sp)
        Surface(
            color = if (signal == "BUY") Green else Muted,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.align(Alignment.TopStart).padding(10.dp)
        ) {
            Text(signal, color = Color.Black, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
        }
    }
}

@Composable
fun InfoCard(title: String, value: String, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(10.dp)) {
            Text(title, color = Muted, fontSize = 11.sp)
            Text(value, color = Text, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun BotsScreen(modifier: Modifier, running: Boolean, onRunning: (Boolean) -> Unit) {
    var showEditor by remember { mutableStateOf(false) }
    var botName by remember { mutableStateOf("Gold Break M5") }
    var condition by remember { mutableStateOf("إغلاق الشمعة فوق المقاومة") }
    Column(modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("البوتات", color = Text, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { showEditor = true }) { Icon(Icons.Default.Add, null, tint = Green) }
        }
        BotCard(botName, "XAUUSD · M5", running, onRunning) { showEditor = true }
        Spacer(Modifier.height(10.dp))
        Text("يمكن تعديل شروط البوت وإضافة بوتات جديدة.", color = Muted)
        if (showEditor) {
            AlertDialog(
                onDismissRequest = { showEditor = false },
                title = { Text("محرر البوت") },
                text = {
                    Column {
                        OutlinedTextField(botName, { botName = it }, label = { Text("اسم البوت") })
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(condition, { condition = it }, label = { Text("شرط الدخول") })
                        Spacer(Modifier.height(8.dp))
                        Text("مثال: يعتمد التأكيد على إغلاق الشمعة، وليس الذيل.", color = Muted, fontSize = 12.sp)
                    }
                },
                confirmButton = { TextButton({ showEditor = false }) { Text("حفظ") } }
            )
        }
    }
}

@Composable
fun BotCard(name: String, sub: String, running: Boolean, onRunning: (Boolean) -> Unit, edit: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(name, color = Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(sub, color = Muted)
                }
                Switch(checked = running, onCheckedChange = onRunning)
            }
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = edit, label = { Text("تعديل") }, leadingIcon = { Icon(Icons.Default.Edit, null) })
                AssistChip(onClick = {}, label = { Text("Webhook") }, leadingIcon = { Icon(Icons.Default.Link, null) })
            }
        }
    }
}

@Composable
fun TradesScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(14.dp)) {
        Text("الصفقات", color = Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        InfoCard("الحالة", "لا توجد صفقات حقيقية متصلة", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("هذه النسخة هي واجهة المشروع الأولية. ربط MT5 سيتم عبر خادم/واجهة API في المرحلة التالية.", color = Muted)
    }
}

@Composable
fun AlertsScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(14.dp)) {
        Text("التنبيهات", color = Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        InfoCard("تنبيه الذهب", "XAUUSD عند كسر المقاومة", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        InfoCard("إشارة", "انتظار إغلاق شمعة M5", Modifier.fillMaxWidth())
    }
}

@Composable
fun SettingsScreen(modifier: Modifier) {
    var webhook by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(14.dp)) {
        Text("الإعدادات", color = Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(webhook, { webhook = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Webhook URL") })
        Spacer(Modifier.height(10.dp))
        Text("سيتم استخدامه لاحقًا لاستقبال إشارات خارجية مثل TradingView.", color = Muted)
        Spacer(Modifier.height(18.dp))
        InfoCard("اتصال MT5", "غير متصل", Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        InfoCard("وضع التشغيل", "Paper / تجريبي", Modifier.fillMaxWidth())
    }
}
