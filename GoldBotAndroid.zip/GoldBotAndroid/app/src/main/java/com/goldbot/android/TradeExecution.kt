
package com.goldbot.android

/**
 * طبقة تنفيذ الصفقات.
 *
 * التطبيق Android لا ينفذ أمر MT5 مباشرة.
 * هذه الطبقة ترسل الإشارة إلى MT5 Bridge / API:
 * BUY  -> فتح شراء
 * SELL -> فتح بيع
 *
 * في النسخة التالية يتم ربطها بخادم حقيقي مع:
 * - symbol
 * - side
 * - volume
 * - stop loss
 * - take profit
 * - client signal id لمنع تكرار نفس الصفقة.
 */
data class TradeSignal(
    val symbol: String,
    val side: Side,
    val entry: Double,
    val stopLoss: Double?,
    val takeProfit: Double?,
    val volume: Double
)

enum class Side { BUY, SELL }

interface TradeExecutor {
    suspend fun execute(signal: TradeSignal): Result<String>
}

/**
 * منفذ تجريبي آمن: لا يفتح صفقات حقيقية.
 * يستبدل لاحقًا بـ MT5BridgeExecutor.
 */
class PaperTradeExecutor : TradeExecutor {
    override suspend fun execute(signal: TradeSignal): Result<String> {
        return Result.success("PAPER ${signal.side} ${signal.symbol} @ ${signal.entry}")
    }
}
